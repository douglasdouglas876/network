document.addEventListener("DOMContentLoaded", function () {
  highlightCurrentMenu();
  setupMobileMenu();
  setupDarkMode();
  setupReveal();
  setupToTop();
  setupLightbox();
  setupCounters();
  setupKeywords();
  setupBucketList();
  setupCheer();
});

function highlightCurrentMenu() {
  var current = location.pathname.split("/").pop() || "Main.html";
  var links = document.querySelectorAll(".nav-links a");

  links.forEach(function (link) {
    var target = link.getAttribute("href").split("/").pop();
    if (target === current) {
      link.classList.add("active");
    }
  });
}

function setupMobileMenu() {
  var toggle = document.getElementById("menuToggle");
  var menu = document.querySelector(".nav-links");
  if (!toggle || !menu) return;

  toggle.addEventListener("click", function () {
    menu.classList.toggle("open");
    toggle.textContent = menu.classList.contains("open") ? "✕" : "☰";
  });
}

function setupDarkMode() {
  var btn = document.getElementById("themeToggle");
  var saved = null;

  try {
    saved = localStorage.getItem("theme");
  } catch (e) {}

  if (saved === "dark") {
    document.body.classList.add("dark");
  }
  if (!btn) return;

  updateIcon();

  btn.addEventListener("click", function () {
    document.body.classList.toggle("dark");
    var isDark = document.body.classList.contains("dark");
    try {
      localStorage.setItem("theme", isDark ? "dark" : "light");
    } catch (e) {}
    updateIcon();
  });

  function updateIcon() {
    btn.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
  }
}

function setupReveal() {
  var items = document.querySelectorAll(".reveal");

  if (!("IntersectionObserver" in window)) {
    items.forEach(function (el) { el.classList.add("visible"); });
    return;
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  items.forEach(function (el) { observer.observe(el); });
}

function setupToTop() {
  var btn = document.createElement("button");
  btn.id = "toTop";
  btn.title = "맨 위로";
  btn.textContent = "↑";
  document.body.appendChild(btn);

  window.addEventListener("scroll", function () {
    btn.classList.toggle("show", window.scrollY > 400);
  });

  btn.addEventListener("click", function () {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

function setupLightbox() {
  var figures = document.querySelectorAll(".gallery figure");
  if (figures.length === 0) return;

  var box = document.createElement("div");
  box.className = "lightbox";
  box.innerHTML =
    '<button class="lb-close" title="닫기">✕</button>' +
    '<button class="lb-prev" title="이전">‹</button>' +
    '<img src="" alt="">' +
    '<button class="lb-next" title="다음">›</button>' +
    "<p></p>";
  document.body.appendChild(box);

  var img = box.querySelector("img");
  var caption = box.querySelector("p");
  var index = 0;

  function show(i) {
    index = (i + figures.length) % figures.length;
    var fig = figures[index];
    var small = fig.querySelector("img");
    var cap = fig.querySelector("figcaption");
    img.src = small.src;
    img.alt = small.alt;
    caption.textContent = cap ? cap.textContent : small.alt;
    box.classList.add("open");
  }

  function close() {
    box.classList.remove("open");
  }

  figures.forEach(function (fig, i) {
    fig.addEventListener("click", function () { show(i); });
  });

  box.querySelector(".lb-close").addEventListener("click", close);
  box.querySelector(".lb-prev").addEventListener("click", function () { show(index - 1); });
  box.querySelector(".lb-next").addEventListener("click", function () { show(index + 1); });

  box.addEventListener("click", function (e) {
    if (e.target === box) close();
  });

  document.addEventListener("keydown", function (e) {
    if (!box.classList.contains("open")) return;
    if (e.key === "Escape") close();
    if (e.key === "ArrowLeft") show(index - 1);
    if (e.key === "ArrowRight") show(index + 1);
  });
}

function setupCounters() {
  var nums = document.querySelectorAll("[data-count]");
  if (nums.length === 0) return;

  function run(el) {
    var goal = parseInt(el.getAttribute("data-count"), 10);
    var now = 0;
    var timer = setInterval(function () {
      now++;
      el.textContent = now;
      if (now >= goal) clearInterval(timer);
    }, 1200 / goal);
  }

  if (!("IntersectionObserver" in window)) {
    nums.forEach(function (el) { el.textContent = el.getAttribute("data-count"); });
    return;
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        run(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  nums.forEach(function (el) { observer.observe(el); });
}

function setupKeywords() {
  var buttons = document.querySelectorAll(".keyword");
  var desc = document.getElementById("keywordDesc");
  if (buttons.length === 0 || !desc) return;

  buttons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      buttons.forEach(function (b) { b.classList.remove("on"); });
      btn.classList.add("on");
      desc.textContent = btn.getAttribute("data-desc");
    });
  });
}

function setupBucketList() {
  var boxes = document.querySelectorAll(".bucket input[type=checkbox]");
  var bar = document.getElementById("bucketBar");
  var label = document.getElementById("bucketText");
  if (boxes.length === 0 || !bar) return;

  function update() {
    var done = 0;
    boxes.forEach(function (b) { if (b.checked) done++; });
    var percent = Math.round((done / boxes.length) * 100);
    bar.style.width = percent + "%";
    label.textContent = done + " / " + boxes.length + " 달성 (" + percent + "%)";

    if (done === boxes.length) {
      alert("🎉 버킷리스트 전부 달성! 다음 도전을 세워 볼까요?");
    }
  }

  boxes.forEach(function (b) { b.addEventListener("change", update); });
  update();
}

function setupCheer() {
  var form = document.getElementById("cheerForm");
  var list = document.getElementById("cheerList");
  if (!form || !list) return;

  var cheers = loadCheers();
  renderCheers();

  var ta = form.querySelector("textarea");
  var counter = form.querySelector(".char-count");
  ta.addEventListener("input", function () {
    counter.textContent = ta.value.length + " / " + ta.maxLength;
  });
  form.addEventListener("reset", function () {
    counter.textContent = "0 / " + ta.maxLength;
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var name = form.elements["name"].value.trim();
    var relation = form.elements["relation"].value;
    var message = form.elements["message"].value.trim();

    if (name === "" || message === "") {
      alert("이름과 메시지를 모두 입력해 주세요!");
      return;
    }

    cheers.unshift({ name: name, relation: relation, message: message });
    saveCheers();
    renderCheers();
    form.reset();
    alert(name + "님, 응원 감사합니다! 😊");
  });

  function renderCheers() {
    list.innerHTML = "";
    if (cheers.length === 0) {
      list.innerHTML = '<p class="cheer-empty">첫 응원을 남겨 주세요!</p>';
      return;
    }
    cheers.forEach(function (c) {
      var card = document.createElement("div");
      card.className = "cheer-card";
      var who = document.createElement("h4");
      var msg = document.createElement("p");
      who.textContent = c.name + " · " + c.relation;
      msg.textContent = c.message;
      card.appendChild(who);
      card.appendChild(msg);
      list.appendChild(card);
    });
  }

  function loadCheers() {
    try {
      return JSON.parse(localStorage.getItem("cheers")) || [];
    } catch (err) {
      return [];
    }
  }

  function saveCheers() {
    try {
      localStorage.setItem("cheers", JSON.stringify(cheers));
    } catch (err) {}
  }
}
