document.addEventListener("DOMContentLoaded", function () {
  setupEnvelope();
  setupLoveButton();
});

function setupEnvelope() {
  var envelope = document.getElementById("envelope");
  var hint = document.getElementById("envHint");
  var section = document.getElementById("letterSection");
  var opened = false;

  envelope.addEventListener("click", function () {
    if (opened) return;
    opened = true;

    envelope.classList.add("open");
    hint.textContent = "편지를 꺼내는 중...";

    setTimeout(function () {
      section.classList.remove("hidden");
      hint.textContent = "▼ 아래로 내려 편지를 읽어 주세요";
      section.scrollIntoView({ behavior: "smooth" });
      showLines();
      burstHearts(12);
    }, 1300);
  });
}

function showLines() {
  var lines = document.querySelectorAll(".letter .line");
  lines.forEach(function (line, i) {
    setTimeout(function () {
      line.classList.add("show");
    }, 600 + i * 900);
  });
}

function setupLoveButton() {
  var btn = document.getElementById("loveBtn");
  var countEl = document.getElementById("loveCount");
  var count = 0;

  btn.addEventListener("click", function () {
    count++;
    countEl.textContent = count;
    burstHearts(5);

    if (count === 10) {
      alert("💗 하트 10개 전송 완료!\n아버지, 어머니 사랑해요. 항상 감사합니다.");
    }
  });
}

function burstHearts(n) {
  var hearts = ["💗", "💖", "❤️", "💕", "🧡"];

  for (var i = 0; i < n; i++) {
    var h = document.createElement("span");
    h.className = "float-heart";
    h.textContent = hearts[Math.floor(Math.random() * hearts.length)];
    h.style.left = Math.random() * 100 + "vw";
    h.style.fontSize = 18 + Math.random() * 26 + "px";
    h.style.animationDuration = 3 + Math.random() * 3 + "s";
    h.style.animationDelay = Math.random() * 0.8 + "s";
    document.body.appendChild(h);

    setTimeout(function (el) {
      el.remove();
    }, 7000, h);
  }
}
